# PRN211
Project cuối kì môn PRN211
- Tên project : MilkTea
- Ngôn ngữ : C# .Net Core

## Cách upload nhé anh em
- Mỗi người tạo 1 branch riêng để up cho đỡ lỗi nhé
- Có thể upload bằng cái gì cũng được ( Github Desktop, VS, VS Code, .. )

## Chia công việc
 - Bá Hùng : Login, Xem thống kê, discount
 - Khắc Hiếu : CRUD menu, account nhân viên
 - Thế Hùng : Xem menu
 - Tuấn Anh : In bill
 - Gia Long : Quản lí kho ( Có thể không có )
 - Kim Long (https://github.com/longcodebad) : - Check out

## Các phần đã ghép