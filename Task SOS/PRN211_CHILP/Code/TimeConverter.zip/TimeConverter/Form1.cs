﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeConverter
{
    public partial class Form1 : Form
    {
        TextBox CurrentTextBox;
        string[] units = { "Hours", "Minutes", "Seconds" };
        double[] NumberOfSeconds = { 60 * 60, 60, 1 };
        public Form1()
        {
            InitializeComponent();
            GenerateButtons();
            CurrentTextBox = tbSource;
            cbSource.DataSource = units;
            cbTarget.DataSource = units.Clone();
            this.cbSource.SelectedIndexChanged += new System.EventHandler(this.cbSource_SelectedIndexChanged);
            this.cbTarget.SelectedIndexChanged += new System.EventHandler(this.cbTarget_SelectedIndexChanged);
        }

        private void GenerateButtons()
        {
            string[] buttonLabels = { "", "CE", "BS",
                                      "7", "8", "9",
                                      "4", "5", "6",
                                      "1", "2", "3",
                                      "", "0", "."};
            int Width = panel1.Width / 3;
            int Height = panel1.Height / 5;
            int x = 0, y = 0;
            for (int i=0; i<buttonLabels.Length; i++)
            {
                if (!buttonLabels[i].Equals(string.Empty))
                {
                    Button newButton = new Button();
                    newButton.Size = new Size(Width, Height);
                    newButton.Location = new Point(x, y);
                    newButton.Text = buttonLabels[i];
                    newButton.Font = new Font("Arial", 14);
                    panel1.Controls.Add(newButton);
                    if (i == 1) newButton.Click += CEButton_Click;
                    else if (i == 2) newButton.Click += BSButton_Click;
                    else if (i == 14) newButton.Click += PointButton_Click;
                    else if (i != 0 && i != 12) newButton.Click += DigitButton_Click;
                }
                if (i % 3 == 2)
                {
                    x = 0;
                    y += Height;
                }
                else x += Width;
            }
        }

        public void CEButton_Click(object sender, EventArgs e)
        {
            CurrentTextBox.Text = "0";
        }

        public void BSButton_Click(object sender, EventArgs e)
        {
            if (CurrentTextBox.Text.Length > 1)
                CurrentTextBox.Text = CurrentTextBox.Text.Substring(0, CurrentTextBox.Text.Length - 1);
            else CurrentTextBox.Text = "0";
        }

        public void PointButton_Click(object sender, EventArgs e)
        {
            if (!CurrentTextBox.Text.Contains(".")) CurrentTextBox.Text += ".";
        }

        public void DigitButton_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (CurrentTextBox.Text.Equals("0")) CurrentTextBox.Text = b.Text;
            else CurrentTextBox.Text += b.Text;
        }

        private void tbSource_TextChanged(object sender, EventArgs e)
        {
            DoConvert();
        }

        private void tbTarget_Enter(object sender, EventArgs e)
        {
            CurrentTextBox = tbTarget;
        }

        private void tbSource_Enter(object sender, EventArgs e)
        {
            CurrentTextBox = tbSource;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tbSource.Text = "0";
            tbTarget.Text = "0";
            cbSource.SelectedIndex = 0;
            cbTarget.SelectedIndex = 1;
        }

        private double UnitConvert(double source, string sourceUnit, string targetUnit)
        {
            double seconds = source * NumberOfSeconds[Array.IndexOf(units, sourceUnit)];
            return seconds/ NumberOfSeconds[Array.IndexOf(units, targetUnit)];
        }

        private void tbTarget_TextChanged(object sender, EventArgs e)
        {
            DoConvert();
            
        }

        private void DoConvert()
        {
            
            if (CurrentTextBox == tbSource)
            {
                //if (tbSource.Text.Equals(String.Empty)) tbSource.Text = "0";
                double value = Convert.ToDouble(tbSource.Text);
                tbTarget.Text = UnitConvert(value, cbSource.SelectedItem.ToString(), cbTarget.SelectedItem.ToString()).ToString();
            }
            else
            {
                //if (tbTarget.Text.Equals(String.Empty)) tbTarget.Text = "0";
                double value = Convert.ToDouble(tbTarget.Text);
                tbSource.Text = UnitConvert(value, cbTarget.SelectedItem.ToString(), cbSource.SelectedItem.ToString()).ToString();
            }
        }

        private void cbSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            DoConvert();
        }

        private void cbTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            DoConvert();
        }
    }
}
