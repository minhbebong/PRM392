﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDataGridView.Logics
{
    class MajorManager
    {
        public static List<string> GetMajors()
        {
            return new List<string> { "SE", "IA", "GD", "AI" };
        }
    }
}
