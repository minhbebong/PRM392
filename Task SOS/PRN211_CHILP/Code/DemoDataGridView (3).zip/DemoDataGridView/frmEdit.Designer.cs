﻿
namespace DemoDataGridView
{
    partial class frmEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbId = new System.Windows.Forms.TextBox();
            this.btEdit = new System.Windows.Forms.Button();
            this.tbName = new System.Windows.Forms.TextBox();
            this.dtpDob = new System.Windows.Forms.DateTimePicker();
            this.nudEntryYear = new System.Windows.Forms.NumericUpDown();
            this.cbMajor = new System.Windows.Forms.ComboBox();
            this.tbScholarship = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudEntryYear)).BeginInit();
            this.SuspendLayout();
            // 
            // tbId
            // 
            this.tbId.Enabled = false;
            this.tbId.Location = new System.Drawing.Point(96, 63);
            this.tbId.Name = "tbId";
            this.tbId.Size = new System.Drawing.Size(190, 23);
            this.tbId.TabIndex = 0;
            // 
            // btEdit
            // 
            this.btEdit.Location = new System.Drawing.Point(99, 351);
            this.btEdit.Name = "btEdit";
            this.btEdit.Size = new System.Drawing.Size(162, 23);
            this.btEdit.TabIndex = 11;
            this.btEdit.Text = "Edit";
            this.btEdit.UseVisualStyleBackColor = true;
            this.btEdit.Click += new System.EventHandler(this.btEdit_Click);
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(99, 107);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(187, 23);
            this.tbName.TabIndex = 7;
            // 
            // dtpDob
            // 
            this.dtpDob.Location = new System.Drawing.Point(99, 147);
            this.dtpDob.Name = "dtpDob";
            this.dtpDob.Size = new System.Drawing.Size(200, 23);
            this.dtpDob.TabIndex = 12;
            // 
            // nudEntryYear
            // 
            this.nudEntryYear.Location = new System.Drawing.Point(99, 191);
            this.nudEntryYear.Name = "nudEntryYear";
            this.nudEntryYear.Size = new System.Drawing.Size(120, 23);
            this.nudEntryYear.TabIndex = 13;
            // 
            // cbMajor
            // 
            this.cbMajor.FormattingEnabled = true;
            this.cbMajor.Location = new System.Drawing.Point(99, 232);
            this.cbMajor.Name = "cbMajor";
            this.cbMajor.Size = new System.Drawing.Size(121, 23);
            this.cbMajor.TabIndex = 14;
            // 
            // tbScholarship
            // 
            this.tbScholarship.Location = new System.Drawing.Point(99, 278);
            this.tbScholarship.Name = "tbScholarship";
            this.tbScholarship.Size = new System.Drawing.Size(121, 23);
            this.tbScholarship.TabIndex = 15;
            // 
            // frmEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbScholarship);
            this.Controls.Add(this.cbMajor);
            this.Controls.Add(this.nudEntryYear);
            this.Controls.Add(this.dtpDob);
            this.Controls.Add(this.btEdit);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.tbId);
            this.Name = "frmEdit";
            this.Text = "frmEdit";
            this.Load += new System.EventHandler(this.frmEdit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudEntryYear)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbId;
        private System.Windows.Forms.Button btEdit;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.DateTimePicker dtpDob;
        private System.Windows.Forms.NumericUpDown nudEntryYear;
        private System.Windows.Forms.ComboBox cbMajor;
        private System.Windows.Forms.TextBox tbScholarship;
    }
}