﻿using DemoDataGridView.Logics;
using DemoDataGridView.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoDataGridView
{
    public partial class frmEdit : Form
    {
        public Student CurrentStudent { get; }
        public frmEdit()
        {
            InitializeComponent();
        }

        public frmEdit(Student s)
        {
            InitializeComponent();
            CurrentStudent = s;
        }

        private void frmEdit_Load(object sender, EventArgs e)
        {
            if (CurrentStudent != null)
                tbId.Text = CurrentStudent.Id.ToString();
            tbName.Text = CurrentStudent.Name;
            dtpDob.Value = CurrentStudent.Dob;

            cbMajor.DataSource = MajorManager.GetMajors();
            cbMajor.SelectedItem = CurrentStudent.Major;

            nudEntryYear.Minimum = 2000;
            nudEntryYear.Maximum = DateTime.Now.Year;
            nudEntryYear.Value = CurrentStudent.EntryYear;

            tbScholarship.Text = CurrentStudent.Scholarship.ToString();
        }

        private Student GetStudentInfo()
        {
            try
            {
                Student s = new Student(
                CurrentStudent.Id,
                tbName.Text.Trim(),
                dtpDob.Value,
                cbMajor.SelectedItem.ToString(),
                (int)nudEntryYear.Value,
                Convert.ToDouble(tbScholarship.Text)
                );
                return s;
            }
            catch (Exception e)
            {
                MessageBox.Show("Co du lieu khong dung." + Environment.NewLine + e.Message);
                return null;
            }
            
        }

        private void btEdit_Click(object sender, EventArgs e)
        {
            Student s = GetStudentInfo();
            if (s != null)
                if (StudentManager.EditStudent(s) > 0)
                    MessageBox.Show("Cap nhat thanh cong");
                else MessageBox.Show("Co loi gi do trong csdl cung khong ro lam.");
        }
    }
}
