﻿using DemoDataGridView.Logics;
using DemoDataGridView.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoDataGridView
{
    public partial class Form1 : Form
    {
        List<Student> Students;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataGridViewButtonColumn editcol = new DataGridViewButtonColumn();
            editcol.Name = "editcol";
            editcol.Text = "Edit";
            editcol.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(editcol);

            Students = StudentManager.GetAllStudentsFromDB();
            dataGridView1.DataSource = Students;
            cbDob.DataSource = StudentManager.GetAllYearOfDob(Students);
            cbEntryYear.DataSource = StudentManager.GetAllEntryYears(Students);

            lbMajor.DataSource = MajorManager.GetMajors();


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (dataGridView1.Columns[e.ColumnIndex].Name.Equals("editcol"))
            {
                //C1
                //string Name = dataGridView1.Rows[e.RowIndex].Cells["NameCol"].Value.ToString();

                //C2
                List<Student> students = (List<Student>)dataGridView1.DataSource;
                string Name = students[e.RowIndex].Name;
                int Id = Convert.ToInt32(students[e.RowIndex].Id);

                frmEdit newform = new frmEdit(students[e.RowIndex]);
                newform.FormClosed += frmEdit_Close;
                newform.Show();
            }
        }

        private void frmEdit_Close(object sender, EventArgs e)
        {
            Students = StudentManager.GetAllStudentsFromDB();
            btSearch_Click(sender, null);
        }

        private void btOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.InitialDirectory = @"D:\";
            dialog.Filter = "Text file|*.txt";
            dialog.Multiselect = false;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string FileName = dialog.FileName;
                tbFileName.Text = FileName;
                Students = StudentManager.GetAllStudents(FileName);
                dataGridView1.DataSource = Students;
                cbDob.DataSource = StudentManager.GetAllYearOfDob(Students);                
                cbEntryYear.DataSource = StudentManager.GetAllEntryYears(Students);

                lbMajor.DataSource = StudentManager.GetAllMajors(Students);
            }
        }

        private void btSearch_Click(object sender, EventArgs e)
        {
            if (Students is null)
            {
                MessageBox.Show("Can load du lieu student truoc.");
                return;
            }
            List<Student> Results = new List<Student>();
            
            if (!tbId.Text.Trim().Equals(String.Empty))
            {                
                Results.Add(StudentManager.SearchById(Students, Convert.ToInt32(tbId.Text.Trim())));
            }
            else
            {
                Results.AddRange(Students);
                //co dieu kien Name ko?
                if (!tbName.Text.Trim().Equals(String.Empty))
                    Results = StudentManager.SearchByName(Results, tbName.Text.Trim());
                //co dieu kien Year of Dob?
                if (cbDob.SelectedIndex != 0)
                    Results = StudentManager.SearchByYearOfDob(Results, Convert.ToInt32(cbDob.SelectedItem));
                //co dieu kien EntryYear
                if (cbEntryYear.SelectedIndex != 0)
                    Results = StudentManager.SearchByEntryYear(Results, Convert.ToInt32(cbEntryYear.SelectedItem));
                //co dieu kien Major
                if (lbMajor.SelectedItems.Count != 0)
                    Results = StudentManager.SearchByMajors(Results, lbMajor.SelectedItems.Cast<string>().ToList());
            }
            dataGridView1.DataSource = Results;
        }
    }
}
