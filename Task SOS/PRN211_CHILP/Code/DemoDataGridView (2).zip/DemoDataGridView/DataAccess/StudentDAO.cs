﻿using DemoDataGridView.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDataGridView.DataAccess
{
    class StudentDAO
    {
        public static List<Student> GetAllStudents()
        {
            string sql = "select * from Students";
            DataTable dt = DAO.GetDataBySql(sql);
            List<Student> list = new List<Student>();
            foreach (DataRow dr in dt.Rows)
                list.Add(new Student(
                    Convert.ToInt32(dr["Id"]),
                    dr["Name"].ToString(),
                    Convert.ToDateTime(dr["Dob"]),
                    dr["Major"].ToString(),
                    Convert.ToInt32(dr["EntryYear"]),
                    Convert.ToDouble(dr["Scholarship"])));
            return list;
        }
    }
}
