﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDataGridView.DataAccess
{
    class DAO
    {
        public static SqlConnection GetConnection()
        {
            string ConStr = "server=LAPTOP-DGQ6A129; database=SE1619_Demo; user=sa; password=123456";
            return new SqlConnection(ConStr);        
        }

        public static DataTable GetDataBySql(string sql)
        {
            SqlCommand command = new SqlCommand(sql, GetConnection());
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(dt);
            return dt;
        }
    }
}
