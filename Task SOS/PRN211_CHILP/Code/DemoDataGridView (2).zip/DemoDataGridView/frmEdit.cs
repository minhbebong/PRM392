﻿using DemoDataGridView.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoDataGridView
{
    public partial class frmEdit : Form
    {
        public Student CurrentStudent { get; }
        public frmEdit()
        {
            InitializeComponent();
        }

        public frmEdit(Student s)
        {
            InitializeComponent();
            CurrentStudent = s;
        }

        private void frmEdit_Load(object sender, EventArgs e)
        {
            if (CurrentStudent != null)
                textBox1.Text = CurrentStudent.Id.ToString();
        }
    }
}
