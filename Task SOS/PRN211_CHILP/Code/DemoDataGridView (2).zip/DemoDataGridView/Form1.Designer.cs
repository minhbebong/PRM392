﻿
namespace DemoDataGridView
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tbFileName = new System.Windows.Forms.TextBox();
            this.btOpen = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btSearch = new System.Windows.Forms.Button();
            this.lbMajor = new System.Windows.Forms.ListBox();
            this.cbEntryYear = new System.Windows.Forms.ComboBox();
            this.cbDob = new System.Windows.Forms.ComboBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbId = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(637, 338);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tbFileName
            // 
            this.tbFileName.Location = new System.Drawing.Point(32, 26);
            this.tbFileName.Name = "tbFileName";
            this.tbFileName.Size = new System.Drawing.Size(144, 23);
            this.tbFileName.TabIndex = 1;
            // 
            // btOpen
            // 
            this.btOpen.Location = new System.Drawing.Point(206, 26);
            this.btOpen.Name = "btOpen";
            this.btOpen.Size = new System.Drawing.Size(95, 23);
            this.btOpen.TabIndex = 2;
            this.btOpen.Text = "OpenFile";
            this.btOpen.UseVisualStyleBackColor = true;
            this.btOpen.Click += new System.EventHandler(this.btOpen_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btSearch);
            this.panel1.Controls.Add(this.lbMajor);
            this.panel1.Controls.Add(this.cbEntryYear);
            this.panel1.Controls.Add(this.cbDob);
            this.panel1.Controls.Add(this.tbName);
            this.panel1.Controls.Add(this.tbId);
            this.panel1.Location = new System.Drawing.Point(698, 73);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(292, 338);
            this.panel1.TabIndex = 3;
            // 
            // btSearch
            // 
            this.btSearch.Location = new System.Drawing.Point(68, 299);
            this.btSearch.Name = "btSearch";
            this.btSearch.Size = new System.Drawing.Size(162, 23);
            this.btSearch.TabIndex = 6;
            this.btSearch.Text = "Search";
            this.btSearch.UseVisualStyleBackColor = true;
            this.btSearch.Click += new System.EventHandler(this.btSearch_Click);
            // 
            // lbMajor
            // 
            this.lbMajor.FormattingEnabled = true;
            this.lbMajor.ItemHeight = 15;
            this.lbMajor.Location = new System.Drawing.Point(68, 184);
            this.lbMajor.Name = "lbMajor";
            this.lbMajor.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbMajor.Size = new System.Drawing.Size(207, 94);
            this.lbMajor.TabIndex = 5;
            this.lbMajor.SelectedIndexChanged += new System.EventHandler(this.btSearch_Click);
            // 
            // cbEntryYear
            // 
            this.cbEntryYear.FormattingEnabled = true;
            this.cbEntryYear.Location = new System.Drawing.Point(68, 141);
            this.cbEntryYear.Name = "cbEntryYear";
            this.cbEntryYear.Size = new System.Drawing.Size(208, 23);
            this.cbEntryYear.TabIndex = 4;
            this.cbEntryYear.SelectedIndexChanged += new System.EventHandler(this.btSearch_Click);
            // 
            // cbDob
            // 
            this.cbDob.FormattingEnabled = true;
            this.cbDob.Location = new System.Drawing.Point(68, 98);
            this.cbDob.Name = "cbDob";
            this.cbDob.Size = new System.Drawing.Size(208, 23);
            this.cbDob.TabIndex = 2;
            this.cbDob.SelectedIndexChanged += new System.EventHandler(this.btSearch_Click);
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(68, 55);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(187, 23);
            this.tbName.TabIndex = 1;
            this.tbName.TextChanged += new System.EventHandler(this.btSearch_Click);
            // 
            // tbId
            // 
            this.tbId.Location = new System.Drawing.Point(68, 17);
            this.tbId.Name = "tbId";
            this.tbId.Size = new System.Drawing.Size(187, 23);
            this.tbId.TabIndex = 0;
            this.tbId.TextChanged += new System.EventHandler(this.btSearch_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btOpen);
            this.Controls.Add(this.tbFileName);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tbFileName;
        private System.Windows.Forms.Button btOpen;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btSearch;
        private System.Windows.Forms.ListBox lbMajor;
        private System.Windows.Forms.ComboBox cbEntryYear;
        private System.Windows.Forms.ComboBox cbDob;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbId;
    }
}

