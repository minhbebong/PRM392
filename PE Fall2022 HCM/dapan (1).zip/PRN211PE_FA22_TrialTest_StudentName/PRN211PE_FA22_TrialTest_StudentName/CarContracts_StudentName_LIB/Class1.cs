﻿namespace CarContracts_StudentName_LIB
{
    public class Class1
    {

    }
}